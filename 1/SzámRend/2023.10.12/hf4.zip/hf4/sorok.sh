#!/bin/sh

cat sorok.txt | head -n $1
cat sorok.txt | tail -n $1
