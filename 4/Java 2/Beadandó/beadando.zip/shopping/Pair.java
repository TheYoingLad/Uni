package shopping;

public record Pair<A, B>(A a, B b) {
}
