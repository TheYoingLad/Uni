package shopping;

public class NonRestrictedCustomer {
}
