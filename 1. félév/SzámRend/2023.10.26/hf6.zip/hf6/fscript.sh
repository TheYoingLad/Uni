#!/bin/sh
for i in `seq 12`
do
    echo hey kiddo | write a7mmz1 pts/8
    sleep 5`
done &