﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HfRegistration
{
    public abstract class Registration
    {
        public abstract int GetSize();
    }
}
