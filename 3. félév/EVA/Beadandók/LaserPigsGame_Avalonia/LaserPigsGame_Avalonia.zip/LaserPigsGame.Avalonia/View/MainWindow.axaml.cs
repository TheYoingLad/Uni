﻿using Avalonia.Controls;

namespace LaserPigsGame.Avalonia.View;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
