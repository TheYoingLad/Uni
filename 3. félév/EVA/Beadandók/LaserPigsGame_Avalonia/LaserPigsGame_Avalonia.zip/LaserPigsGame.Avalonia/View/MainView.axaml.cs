﻿using Avalonia.Controls;

namespace LaserPigsGame.Avalonia.View;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}